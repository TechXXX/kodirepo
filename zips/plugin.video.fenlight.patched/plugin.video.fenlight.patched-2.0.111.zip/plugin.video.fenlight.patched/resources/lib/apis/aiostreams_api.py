# -*- coding: utf-8 -*-
import base64
import json
import re
from urllib.parse import quote, urljoin, urlsplit, urlunsplit
from modules.kodi_utils import make_session, logger
from caches.settings_cache import get_setting

user_agent = 'AIOStreams/FenLight'
default_base_url = 'https://aiostreamsfortheweebsstable.midnightignite.me'
timeout = 25.0
session = make_session(default_base_url)


class AIOStreamsAPI:
	def __init__(self, manifest_url=None):
		self.manifest_url = manifest_url or get_setting('fenlight.tb.usenet_search.aiostreams_manifest', 'empty_setting')
		self.api_base = self._api_base_from_manifest(self.manifest_url)
		self.stream_base = self._stream_base_from_manifest(self.manifest_url)

	def enabled(self):
		return bool(self.api_base or self.stream_base)

	def usenet_streams(self, media_type, imdb_id='', tmdb_id='', season=None, episode=None):
		try:
			if not self.enabled(): return []
			stremio_type, stremio_id = self._stremio_request_id(media_type, imdb_id, tmdb_id, season, episode)
			if not stremio_type or not stremio_id: return []
			results = self._search_api_results(stremio_type, stremio_id)
			if results: return results
			if not self.stream_base: return []
			url = '%s/stream/%s/%s.json' % (self.stream_base, stremio_type, quote(stremio_id, safe=':'))
			response = session.get(url, headers={'User-Agent': user_agent, 'Accept': 'application/json'}, timeout=timeout)
			content_type = response.headers.get('Content-Type', '')
			content_length = len(response.content or b'')
			try:
				data = response.json()
			except Exception as e:
				logger('Fen Light Patched', 'AIOStreams stream fallback non-json | status=%s | content_type=%s | bytes=%s | prefix=%s | error=%s | type=%s | id=%s' % (
					response.status_code, content_type, content_length, self._response_prefix(response), str(e), stremio_type, stremio_id))
				return []
			if not response.ok:
				logger('Fen Light Patched', 'AIOStreams stream fallback unavailable | status=%s | content_type=%s | bytes=%s | type=%s | id=%s' % (
					response.status_code, content_type, content_length, stremio_type, stremio_id))
				return []
			streams = data.get('streams') or []
			return [i for i in (self._parse_stream(stream) for stream in streams) if i]
		except Exception as e:
			logger('Fen Light Patched', 'AIOStreams TorBox Usenet Search exception | %s' % str(e))
			return []

	def _api_base_from_manifest(self, manifest_url):
		manifest_url = (manifest_url or '').strip()
		if manifest_url in ('', 'empty_setting'): return ''
		if manifest_url.lower() == 'midnight': manifest_url = default_base_url
		if manifest_url.startswith('stremio://'): manifest_url = 'https://%s' % manifest_url.split('://', 1)[1]
		elif manifest_url.startswith('://'): manifest_url = 'https%s' % manifest_url
		elif manifest_url.startswith('aiostreams.'): manifest_url = 'https://%s' % manifest_url
		elif re.match(r'^[0-9a-f-]{36}/[^/]+/?(?:manifest\.json)?$', manifest_url, re.I):
			manifest_url = '%s/stremio/%s' % (default_base_url, manifest_url)
		parts = urlsplit(manifest_url)
		if not parts.scheme or not parts.netloc: return ''
		return urlunsplit((parts.scheme, parts.netloc, '', '', '')).rstrip('/')

	def _stream_base_from_manifest(self, manifest_url):
		manifest_url = (manifest_url or '').strip()
		if manifest_url in ('', 'empty_setting'): return ''
		if manifest_url.lower() == 'midnight': manifest_url = default_base_url
		if manifest_url.startswith('stremio://'): manifest_url = 'https://%s' % manifest_url.split('://', 1)[1]
		elif manifest_url.startswith('://'): manifest_url = 'https%s' % manifest_url
		elif manifest_url.startswith('aiostreams.'): manifest_url = 'https://%s' % manifest_url
		elif re.match(r'^[0-9a-f-]{36}/[^/]+/?(?:manifest\.json)?$', manifest_url, re.I):
			manifest_url = '%s/stremio/%s' % (default_base_url, manifest_url)
		parts = urlsplit(manifest_url)
		if not parts.scheme or not parts.netloc: return ''
		path = parts.path.strip('/')
		if path.endswith('manifest.json'): path = path.rsplit('/', 1)[0]
		path_parts = path.split('/') if path else []
		try: stremio_index = path_parts.index('stremio')
		except ValueError: return ''
		if len(path_parts) < stremio_index + 3: return ''
		base_path = '/' + '/'.join(path_parts[:stremio_index + 3])
		return urlunsplit((parts.scheme, parts.netloc, base_path, '', '')).rstrip('/')

	def _stremio_request_id(self, media_type, imdb_id='', tmdb_id='', season=None, episode=None):
		imdb_id = (imdb_id or '').strip()
		tmdb_id = str(tmdb_id or '').strip()
		if re.match(r'^tt\d+$', imdb_id) and imdb_id != 'tt0000000': base_id = imdb_id
		elif tmdb_id:
			converted_imdb_id = self._imdb_id_from_tmdb(media_type, tmdb_id)
			base_id = converted_imdb_id or 'tmdb:%s' % tmdb_id
		else: return '', ''
		if media_type == 'movie': return 'movie', base_id
		if not season or not episode: return '', ''
		return 'series', '%s:%s:%s' % (base_id, int(season), int(episode))

	def _imdb_id_from_tmdb(self, media_type, tmdb_id):
		try:
			if not tmdb_id or str(tmdb_id) == '0000000': return ''
			from apis.tmdb_api import tmdb_external_ids
			ids = tmdb_external_ids(media_type, tmdb_id)
			imdb_id = (ids or {}).get('imdb_id') or ''
			if re.match(r'^tt\d+$', imdb_id) and imdb_id != 'tt0000000': return imdb_id
		except Exception as e:
			logger('Fen Light Patched', 'AIOStreams TMDb to IMDb conversion exception | media=%s | tmdb=%s | error=%s' % (
				media_type, tmdb_id, str(e)))
		return ''

	def _search_api_results(self, stremio_type, stremio_id):
		try:
			if not self.api_base: return []
			api_key = get_setting('fenlight.tb.token', 'empty_setting')
			if api_key in ('', 'empty_setting', None): return []
			user_data = {
				'sortCriteria': {'global': []},
				'deduplicator': {'enabled': False},
				'formatter': {'id': 'torrentio'},
				'presets': [{
					'type': 'torbox-search', 'instanceId': 'fenlight', 'enabled': True,
					'options': {
						'timeout': int(timeout * 1000), 'name': 'TorBoxSearch',
						'sources': ['usenet'], 'mediaTypes': [], 'useMultipleInstances': False,
						'userSearchEngines': True, 'onlyShowUserSearchResults': False
					}
				}],
				'services': [{'id': 'torbox', 'enabled': True, 'credentials': {'apiKey': api_key}}]
			}
			headers = {
				'User-Agent': user_agent, 'Accept': 'application/json',
				'x-aiostreams-user-data': base64.b64encode(json.dumps(user_data, separators=(',', ':')).encode()).decode()
			}
			url = '%s/api/v1/search' % self.api_base
			response = session.get(url, params={'type': stremio_type, 'id': stremio_id}, headers=headers, timeout=timeout)
			content_type = response.headers.get('Content-Type', '')
			content_length = len(response.content or b'')
			try:
				data = response.json()
			except Exception as e:
				logger('Fen Light Patched', 'AIOStreams Search API non-json | status=%s | content_type=%s | bytes=%s | prefix=%s | error=%s | type=%s | id=%s' % (
					response.status_code, content_type, content_length, self._response_prefix(response), str(e), stremio_type, stremio_id))
				return []
			if not response.ok:
				logger('Fen Light Patched', 'AIOStreams Search API unavailable | status=%s | error=%s' % (response.status_code, data.get('error') or data.get('message') or 'unknown'))
				return []
			results = ((data.get('data') or {}).get('results') or [])
			return [i for i in (self._parse_search_result(item) for item in results) if i]
		except Exception as e:
			logger('Fen Light Patched', 'AIOStreams Search API exception | %s' % str(e))
			return []

	def _parse_search_result(self, item):
		if item.get('cached') is not True: return None
		nzb = item.get('nzbUrl')
		if not nzb: return None
		file_name = item.get('filename') or item.get('folderName') or item.get('name') or ''
		if not file_name: return None
		size = self._to_int(item.get('size'))
		folder_size = self._to_int(item.get('folderSize'))
		return {
			'name': file_name, 'short_name': file_name, 'size': size or folder_size or 0,
			'nzb': nzb, 'hash': item.get('infoHash') or nzb,
			'direct_debrid_link': 'usenet_search', 'package': '',
			'package_size': folder_size if folder_size and size and folder_size > size else 0,
			'indexer': item.get('indexer'), 'age': item.get('age')
		}

	def _parse_stream(self, stream):
		stream_data = stream.get('streamData') or {}
		if not stream_data: return self._parse_stream_fallback(stream)
		service = stream_data.get('service') or {}
		if stream_data.get('type') != 'usenet': return None
		if service.get('id') != 'torbox' or service.get('cached') is not True: return None
		addon = stream_data.get('addon') or ''
		if addon and addon != 'TorBox Search': return None
		nzb = stream_data.get('nzbUrl')
		if not nzb: return None
		behavior = stream.get('behaviorHints') or {}
		file_name = stream_data.get('filename') or behavior.get('filename') or stream_data.get('folderName') or self._fallback_name(stream)
		if not file_name: return None
		size = self._to_int(behavior.get('videoSize') or stream_data.get('size'))
		folder_size = self._to_int(behavior.get('folderSize') or stream_data.get('folderSize'))
		return {
			'name': file_name, 'short_name': file_name, 'size': size or folder_size or 0,
			'nzb': nzb, 'hash': stream.get('infoHash') or nzb,
			'direct_debrid_link': 'usenet_search', 'package': '',
			'package_size': folder_size if folder_size and size and folder_size > size else 0,
			'indexer': stream_data.get('indexer'), 'age': stream_data.get('age')
		}

	def _parse_stream_fallback(self, stream):
		return None

	def _absolute_url(self, url):
		if url.startswith(('http://', 'https://')): return url
		parts = urlsplit(self.stream_base)
		return urljoin('%s://%s' % (parts.scheme, parts.netloc), url)

	def _fallback_name(self, stream):
		description = stream.get('description') or ''
		for item in description.splitlines():
			item = item.strip()
			if item: return item
		return (stream.get('name') or '').strip()

	def _filename_from_description(self, description):
		return self._description_value(description, '\U0001f4c1')

	def _description_value(self, description, marker):
		try:
			if not marker in description: return ''
			value = description.split(marker, 1)[1].split('|', 1)[0].strip()
			return value
		except: return ''

	def _to_int(self, value):
		try: return int(float(value))
		except: return 0

	def _response_prefix(self, response):
		try: return (response.text or '').replace('\r', ' ').replace('\n', ' ')[:160]
		except: return ''
