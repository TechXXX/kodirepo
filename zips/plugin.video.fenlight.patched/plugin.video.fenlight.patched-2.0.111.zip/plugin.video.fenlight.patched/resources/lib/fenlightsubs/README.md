# Fen Light Subtitle Selector Notes

This package is Fen Light Patched's bundled source/subtitle matching layer.
Read this before changing autoplay subtitle ranking.

## Files

- `subtitle_selector.py`
  Deterministic scoring policy for matching source release names to subtitle
  filenames/comments.
- `integration.py`
  Adapter between Fen source dictionaries, a4k subtitle result dictionaries,
  and the standalone selector API.

## Responsibilities

The selector owns:

- release-name normalization
- subtitle filename versus comment scoring
- translated-subtitle demotion
- generic title-only fallback demotion
- returning ranked source/subtitle pairs

The selector does not own:

- Fen source scraping
- a4k provider searches
- Kodi playback
- runtime subtitle download or attachment
- TMDb title alias policy

## Fen/a4k Contract

`integration.rank_kodi_sources_by_subtitles(...)` receives Fen source rows and
a4k subtitle rows. It returns ranked items while preserving the original source
and subtitle objects.

When adapting a4k rows, treat `action_args.release_name` as the provider
release identity. `action_args.filename` and top-level `name` can be shorter
display stems and should only be fallbacks/context. This matters for exact
scene/source matches such as:

- source: `Mean.Girls.2004.1080p.BluRay.x265-RARBG`
- a4k display filename: `Mean.Girls.2004.1080p.BluRay`
- a4k release identity:
  `action_args.release_name = Mean.Girls.2004.1080p.BluRay.x265-RARBG`

The release identity should score as `exact_normalized_match` (`100`) and beat
generic title/year subtitles such as `Mean Girls (2004)`, which normally score
as containment matches.

`integration.build_kodi_selector_playback_metadata(...)` attaches runtime
metadata back to a Fen source:

- `selector_source_key`
- `selector_match_score`
- `selector_match_reason`
- `selector_matched_subtitle`
- `selector_requires_ai_translation`
- `selector_subtitle_payload`

`player.py` later publishes `selector_source_key` and
`selector_subtitle_payload` as Kodi window properties for patched a4k's service
loop.

## Debug Artifacts On The MacBook

For live Kodi runs on this Mac, start with:

- current Kodi log:
  `/Users/kalter/Library/Logs/kodi.log`
- previous Kodi log after restart:
  `/Users/kalter/Library/Logs/kodi.old.log`
- selector shadow snapshots:
  `/Users/kalter/Library/Application Support/Kodi/userdata/addon_data/plugin.video.fenlight/subtitle_selector_shadow`
- patched a4k downloaded subtitle temp files:
  `/Users/kalter/Library/Application Support/Kodi/userdata/addon_data/service.subtitles.a4ksubtitles.patched/temp`

The selector shadow directory intentionally uses the unpatched
`plugin.video.fenlight` profile name. Useful files include
`sources_<timestamp>.json`, `subtitles_<timestamp>.json`, `latest_sources*.json`,
and `trace_*.json`.

## Change Policy

If a subtitle-backed source is promoted incorrectly, start here. Prefer a
small selector scoring change with a clear fixture or debug trace over an ad
hoc sort rule in `sources.py`.

Before changing score constants, inspect the adapted fields. Many a4k results
carry their best release identity under `action_args.release_name`; a shorter
visible name is not proof that a better release match is unavailable.

Do not solve media-title edge cases by hardcoding individual titles. If the
problem is that providers use a different show identity than TMDb, document the
case and keep source results honest.
