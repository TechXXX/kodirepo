# -*- coding: utf-8 -*-
import xbmc, xbmcgui
import json
from threading import Thread

pause_services_prop = 'fenlight.pause_services'
current_skin_prop = 'fenlight.current_skin'
trakt_service_string = 'TraktMonitor Service Update %s - %s'
trakt_success_line_dict = {'success': 'Trakt Update Performed', 'no account': '(Unauthorized) Trakt Update Performed'}
update_string = 'Next Update in %s minutes...'
old_trakt_client_id = '1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb'
old_aiostreams_elfhosted_host = 'aiostreams.elfhosted.com'
default_aiostreams_midnight_url = 'https://aiostreamsfortheweebsstable.midnightignite.me'

def logger(heading, function):
	xbmc.log('###%s###: %s' % (heading, function), 1)

class SetAddonConstants:
	def run(self):
		logger('Fen Light Patched', 'SetAddonConstants Service Starting')
		import xbmcgui, xbmcaddon, xbmcvfs
		addon_object = xbmcaddon.Addon('plugin.video.fenlight.patched')
		self.window = xbmcgui.Window(10000)
		_info = addon_object.getAddonInfo
		addon_items = [('fenlight.addon_version', _info('version')),
					('fenlight.addon_path', _info('path')),
					('fenlight.addon_profile', xbmcvfs.translatePath(_info('profile'))),
					('fenlight.addon_icon', xbmcvfs.translatePath(_info('icon'))),
					('fenlight.addon_fanart', xbmcvfs.translatePath(_info('fanart')))]
		for item in addon_items: self.set_property(*item)
		return logger('Fen Light Patched', 'SetAddonConstants Service Finished')

	def set_property(self, prop, value):
		self.window.setProperty(prop, value)

class DatabaseMaintenance:
	def run(self):
		logger('Fen Light Patched', 'DatabaseMaintenance Service Starting')
		from caches.base_cache import make_databases
		make_databases()
		return logger('Fen Light Patched', 'DatabaseMaintenance Service Finished')

class SyncSettings:
	def run(self):
		logger('Fen Light Patched', 'SyncSettings Service Starting')
		from caches.settings_cache import sync_settings
		sync_settings()
		try:
			from apis.trakt_api import sync_trakt_auth_state
			sync_trakt_auth_state()
		except: pass
		logger('Fen Light Patched', 'SyncSettings Service Finished')

class OnUpdateChanges:
	def run(self):
		logger('Fen Light Patched', 'OnUpdateChanges Service Starting')
		from caches.settings_cache import get_setting, set_setting
		try:
			migrations = (
				('refresh_addon_keys', self.refresh_addon_keys),
				('migrate_tb_usenet_aiostreams_url', self.migrate_tb_usenet_aiostreams_url),
				('default_ui_language_dutch', self.default_ui_language_dutch),
				('migrate_external_scraper_to_magneto', self.migrate_external_scraper_to_magneto),
				('sync_live_magneto_provider_defaults', self.sync_live_magneto_provider_defaults)
			)
			for setting_id, migration in migrations:
				update_setting_id = 'updatechecks.%s' % setting_id
				if get_setting('fenlight.%s' % update_setting_id, 'false') == 'true': continue
				migration()
				set_setting(update_setting_id, 'true')
		except Exception as e: logger('Fen Light Patched', 'OnUpdateChanges Service Failed: %s' % str(e))
		return logger('Fen Light Patched', 'OnUpdateChanges Service Finished')

	def refresh_addon_keys(self):
		from caches.settings_cache import get_setting, set_setting, restore_setting_default
		current_trakt_client = (get_setting('fenlight.trakt.client') or '').lower()
		if current_trakt_client != old_trakt_client_id: return
		from caches.trakt_cache import clear_all_trakt_cache_data
		from modules import kodi_utils
		restore_setting_default({'silent': 'true', 'setting_id': 'trakt.client'})
		restore_setting_default({'silent': 'true', 'setting_id': 'trakt.secret'})
		setting_resets = (
			('trakt.user', 'empty_setting'),
			('trakt.expires', ''),
			('trakt.token', ''),
			('trakt.refresh', ''),
			('trakt.next_daily_clear', '0'),
			('trakt.auth_state', 'not_authorized'),
			('trakt.auth_state_display_name', 'Not Authorized'),
			('watched_indicators', '0')
		)
		for setting_id, value in setting_resets: set_setting(setting_id, value)
		clear_all_trakt_cache_data(silent=True, refresh=False)
		logger('Fen Light Patched', 'Old Trakt client ID detected. Trakt credentials reset; reauthorization required.')
		kodi_utils.ok_dialog(
			heading='Trakt Credentials Reset',
			text='Fen Light Patched has replaced an old Trakt app key with the current default.[CR][CR]Please re-authorize your Trakt account.'
		)

	def migrate_tb_usenet_aiostreams_url(self):
		from urllib.parse import urlsplit
		from caches.settings_cache import get_setting, set_setting
		current_url = (get_setting('fenlight.tb.usenet_search.aiostreams_manifest', '') or '').strip()
		if not current_url: return
		try:
			test_url = current_url
			if test_url.startswith('stremio://'): test_url = 'https://%s' % test_url.split('://', 1)[1]
			elif test_url.startswith('://'): test_url = 'https%s' % test_url
			elif test_url.startswith('aiostreams.'): test_url = 'https://%s' % test_url
			host = urlsplit(test_url).netloc.lower()
			if host != old_aiostreams_elfhosted_host: return
			set_setting('tb.usenet_search.aiostreams_manifest', default_aiostreams_midnight_url)
			logger('Fen Light Patched', 'TorBox Usenet AIOStreams URL migrated from ElfHosted public instance to Midnight.')
		except Exception as e:
			logger('Fen Light Patched', 'TorBox Usenet AIOStreams URL migration failed: %s' % str(e))

	def default_ui_language_dutch(self):
		from caches.settings_cache import set_setting
		set_setting('ui_language', 'nl')
		logger('Fen Light Patched', 'Default UI language set to Dutch')

	def migrate_external_scraper_to_magneto(self):
		from caches.settings_cache import get_setting, set_setting
		current_module = get_setting('fenlight.external_scraper.module', '')
		if current_module != 'script.module.cocoscrapers': return
		try:
			import xbmcaddon
			xbmcaddon.Addon('script.module.magneto')
		except Exception as e:
			raise Exception('Magneto module unavailable: %s' % str(e))
		self.apply_magneto_provider_defaults()
		self.sync_magneto_undesirables_from_coco()
		set_setting('external_scraper.module', 'script.module.magneto')
		set_setting('external_scraper.name', 'Magneto Module')
		logger('Fen Light Patched', 'External scraper migrated from CocoScrapers to Magneto.')

	def sync_live_magneto_provider_defaults(self):
		if not self.apply_magneto_provider_defaults():
			raise Exception('Magneto provider defaults were not applied.')

	def apply_magneto_provider_defaults(self):
		try:
			import os, xbmcaddon, xml.etree.ElementTree as ET
			magneto_addon = xbmcaddon.Addon('script.module.magneto')
			settings_path = os.path.join(magneto_addon.getAddonInfo('path'), 'resources', 'settings.xml')
			settings_root = ET.parse(settings_path).getroot()
			provider_defaults = []
			for item in settings_root.iter('setting'):
				setting_id = item.attrib.get('id', '')
				setting_default = item.attrib.get('default')
				if setting_id.startswith('provider.') and setting_default in ('true', 'false'):
					provider_defaults.append((setting_id, setting_default))
			if not provider_defaults: raise Exception('No Magneto provider defaults found.')
			for setting_id, setting_default in provider_defaults:
				magneto_addon.setSetting(setting_id, setting_default)
			logger('Fen Light Patched', 'Applied %s Magneto provider defaults.' % len(provider_defaults))
			return True
		except Exception as e:
			logger('Fen Light Patched', 'Magneto provider defaults sync failed: %s' % str(e))
			return False

	def sync_magneto_undesirables_from_coco(self):
		coco_settings = {
			'filter.undesirables': 'true',
			'filter.foreign.single.audio': 'true'
		}
		try:
			import xbmcaddon
			try:
				coco_addon = xbmcaddon.Addon('script.module.cocoscrapers')
				for setting_id in coco_settings:
					value = coco_addon.getSetting(setting_id)
					if value in ('true', 'false'): coco_settings[setting_id] = value
			except Exception as e:
				logger('Fen Light Patched', 'CocoScrapers undesirables settings unavailable; using Coco defaults: %s' % str(e))
			magneto_addon = xbmcaddon.Addon('script.module.magneto')
			for setting_id, value in coco_settings.items():
				magneto_addon.setSetting(setting_id, value)
		except Exception as e:
			logger('Fen Light Patched', 'Magneto undesirables settings sync failed: %s' % str(e))
		try:
			self.merge_magneto_undesirables_database()
		except Exception as e:
			logger('Fen Light Patched', 'Magneto undesirables database sync failed: %s' % str(e))

	def merge_magneto_undesirables_database(self):
		import os, sqlite3, xbmcvfs
		profile_path = xbmcvfs.translatePath('special://profile/addon_data')
		coco_db = os.path.join(profile_path, 'script.module.cocoscrapers', 'undesirables.db')
		magneto_profile = os.path.join(profile_path, 'script.module.magneto')
		magneto_db = os.path.join(magneto_profile, 'undesirables.db')
		if not os.path.exists(coco_db): return
		if not os.path.exists(magneto_profile): os.makedirs(magneto_profile)
		with sqlite3.connect(coco_db) as coco_con:
			rows = coco_con.execute('SELECT keyword, user_defined, enabled FROM undesirables').fetchall()
		if not rows: return
		with sqlite3.connect(magneto_db) as magneto_con:
			magneto_con.execute('CREATE TABLE IF NOT EXISTS undesirables (keyword TEXT NOT NULL, user_defined BOOL NOT NULL, enabled BOOL NOT NULL, UNIQUE(keyword))')
			magneto_con.executemany('INSERT OR REPLACE INTO undesirables VALUES (?, ?, ?)', rows)
			magneto_con.commit()
		logger('Fen Light Patched', 'Copied %s CocoScrapers undesirables entries to Magneto.' % len(rows))

class CustomFonts:
	def run(self):
		logger('Fen Light Patched', 'CustomFonts Service Starting')
		from windows.base_window import FontUtils
		monitor, player, window = xbmc.Monitor(), xbmc.Player(), xbmcgui.Window(10000)
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		window.clearProperty(current_skin_prop)
		font_utils = FontUtils()
		while not monitor.abortRequested():
			font_utils.execute_custom_fonts()
			if window.getProperty(pause_services_prop) == 'true' or is_playing(): sleep = 20
			else: sleep = 10
			wait_for_abort(sleep)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return logger('Fen Light Patched', 'CustomFonts Service Finished')

class TraktMonitor:
	def run(self):
		logger('Fen Light Patched', 'TraktMonitor Service Starting')
		from apis.trakt_api import trakt_sync_activities
		from caches.settings_cache import get_setting
		from modules.kodi_utils import run_plugin
		from modules.settings import trakt_sync_interval
		monitor, player, window = xbmc.Monitor(), xbmc.Player(), xbmcgui.Window(10000)
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while is_playing() or window.getProperty(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				sync_interval, wait_time = trakt_sync_interval()
				next_update_string = update_string % sync_interval
				status = trakt_sync_activities()
				if status == 'failed': logger('Fen Light Patched', trakt_service_string % ('Failed. Error from Trakt', next_update_string))
				else:
					if status in ('success', 'no account'): logger('Fen Light Patched', trakt_service_string % ('Success. %s' % trakt_success_line_dict[status], next_update_string))
					else: logger('Fen Light Patched', trakt_service_string % ('Success. No Changes Needed', next_update_string))# 'not needed'
					if status == 'success' and get_setting('fenlight.trakt.refresh_widgets', 'false') == 'true': run_plugin({'mode': 'kodi_refresh'})
			except Exception as e: logger('Fen Light Patched', trakt_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return logger('Fen Light Patched', 'TraktMonitor Service Finished')

class WidgetRefresher:
	def run(self):
		logger('Fen Light Patched', 'WidgetRefresher Service Starting')
		from time import time
		from caches.settings_cache import get_setting
		from modules.kodi_utils import home, run_plugin
		monitor, player = xbmc.Monitor(), xbmc.Player()
		wait_for_abort, self.is_playing = monitor.waitForAbort, player.isPlayingVideo
		self.window = xbmcgui.Window(10000)
		self.get_setting = get_setting
		self.home = home
		self.window.setProperty('fenlight.refresh_widgets', 'true')
		self.set_next_refresh(time())
		wait_for_abort(20)
		while not monitor.abortRequested():
			try:
				wait_for_abort(10)
				self.window.clearProperty('fenlight.refresh_widgets')
				offset = int(self.get_setting('fenlight.widget_refresh_timer', '60'))
				if offset != self.offset:
					self.set_next_refresh(time())
					continue
				if self.condition_check(): continue
				if self.next_refresh < time():
					run_plugin({'mode': 'refresh_widgets', 'show_notification': self.get_setting('fenlight.widget_refresh_notification', 'false')}, block=True)
					logger('Fen Light Patched', 'WidgetRefresher Service - Widgets Refreshed')
					self.set_next_refresh(time())
			except: pass
		try: del monitor
		except: pass
		try: del player
		except: pass
		return logger('Fen Light Patched', 'WidgetRefresher Service Finished')

	def condition_check(self):
		if not self.home(): return True
		if self.next_refresh == None or self.is_playing() or self.window.getProperty(pause_services_prop) == 'true': return True
		if self.window.getProperty('fenlight.window_loaded') == 'true': return True 
		try:
			window_stack = json.loads(self.window.getProperty('fenlight.window_stack'))
			if window_stack or window_stack == []: return True
		except: pass
		return False

	def set_next_refresh(self, _time):
		self.offset = int(self.get_setting('fenlight.widget_refresh_timer', '60'))
		if self.offset: self.next_refresh = _time + (self.offset*60)
		else: self.next_refresh = None

class AutoStart:
	def run(self):
		logger('Fen Light Patched', 'AutoStart Service Starting')
		from modules.settings import auto_start_fenlight
		if auto_start_fenlight():
			from modules.kodi_utils import run_addon
			run_addon()
		return logger('Fen Light Patched', 'AutoStart Service Finished')

class FenLightMonitor(xbmc.Monitor):
	def __init__ (self):
		xbmc.Monitor.__init__(self)
		self.startServices()

	def startServices(self):
		SetAddonConstants().run()
		DatabaseMaintenance().run()
		SyncSettings().run()
		OnUpdateChanges().run()
		Thread(target=CustomFonts().run).start()
		Thread(target=TraktMonitor().run).start()
		Thread(target=WidgetRefresher().run).start()
		AutoStart().run()

	def onNotification(self, sender, method, data):
		if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
			xbmcgui.Window(10000).setProperty(pause_services_prop, 'true')
			logger('OnNotificationActions', 'PAUSING Fen Light Patched Services Due to Device Sleep')
		elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
			xbmcgui.Window(10000).clearProperty(pause_services_prop)
			logger('OnNotificationActions', 'UNPAUSING Fen Light Patched Services Due to Device Awake')

logger('Fen Light Patched', 'Main Monitor Service Starting')
FenLightMonitor().waitForAbort()
logger('Fen Light Patched', 'Main Monitor Service Finished')
