# modified by kodifitzwell for Fenomscrapers
"""
	Fenomscrapers Project
"""

import re
from urllib.parse import quote_plus, unquote_plus
from cocoscrapers.modules import coco_client as client, coco_compat as source_utils


class source:
	priority = 3
	pack_capable = True
	hasMovies = True
	hasEpisodes = True
	headers = {'User-Agent': client.randomagent()}
	def __init__(self):
		self.language = ['en']
		self.base_link = 'https://rutor.info'
# 1st param =
# 2nd param = Category
# 3rd param =
# 4th param = Sort
# Date Added  : decreasing=0, increasing=1
# Distributing: decreasing=2, increasing=3
# Rocking     : decreasing=4, increasing=5
# Name        : decreasing=6, increasing=7
# Size        : decreasing=8, increasing=9
# Relevance   : decreasing=10, increasing=11
		self.search_link = '/search/%s/%s'
		self.movie_params = '0/0/0/8' # Foreign Movie = 0/1/110/8
		self.tvshow_params = '0/0/0/8' # Foreign TV = 0/4/110/8
		self.min_seeders = 0

	def get_sources(self, url, collector):
		try:
			results = client.session.request('get', url, headers=self.headers, timeout=7).text
			if not results or '<div id="index">' not in results: return
			table = client.parseDOM(results, 'div', attrs={'id': 'index'})
			rows = client.parseDOM(table, 'tr')
			files = []
			for row in rows:
				try:
					if 'magnet:' not in row: continue
					columns = re.findall(r'<td.*?>(.*?)</td>', row, re.DOTALL)
					url = re.search(r'href\s*=\s*["\'](magnet:.+?)["\']', columns[1], re.I).group(1)
					url = unquote_plus(url).replace('&amp;', '&').replace('&#x3D;', '=').split('&tr')[0]
					url = url.replace('&dn=rutor.info', '&dn=[rutor.info]')
					# url = unquote_plus(client.replaceHTMLCodes(link[0])).split('&tr')[0]
					# url = re.sub(r'(&tr=.+)&dn=', '&dn=', url).replace(' ', '.') # some links on bitsearch &tr= before &dn=
					hash = re.search(r'btih:(.*?)&', url, re.I).group(1)
					parsed_title = re.search(r'/torrent/.+?["\']>(.+?)<', columns[1], re.I).group(1)
					try:
						seeders = client.parseDOM(columns[-1], 'span', attrs={'class': 'green'}) # some results have comments so seeders is always last col from end
						seeders = re.search(r'/>(.+)', seeders[0], re.I).group(1).replace('&nbsp;', ' ')
						if 'K' in seeders: seeders = float(seeders.rstrip('K')) * 1000
					except: seeders = 0
					size = columns[-2].replace('&nbsp;', ' ') # some results have comments so size is always 2nd col from end
					files.append({'hash': hash, 'title': parsed_title, 'seeders': seeders, 'size': size})
				except: pass
			collector.extend(files)
		except:
			source_utils.scraper_error('RUTOR')

	def sources(self, data, hostDict):
		if not data or 'tvshowtitle' in data: return []
		files = []
		sources = []
		sources_append = sources.append
		try:
			aliases = source_utils.aliases_to_array(data['aliases'])
			title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
			episode_title = None
			year = data['year']
			hdlr = year

			query = '%s %s' % (title, hdlr)
			query = re.sub(r'[^A-Za-z0-9\s\.-]+', '', query)
			url = self.search_link % (self.movie_params, quote_plus(query))
			url = '%s%s' % (self.base_link, url)
			# log_utils.log('url = %s' % url)
			self.get_sources(url, files)
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('RUTOR')
			return sources

		for file in files:
			try:
				hash = file['hash']
				name = file['title']

				name = source_utils.clean_name(name).replace('2./.', '').replace('./.', '').replace('|.', '').replace('...', '.').replace('..', '.').replace(',.', '.').replace(':.', '.')

				if not source_utils.check_title(title, aliases, name, hdlr, year): continue
				name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				if not episode_title: # filter for eps returned in movie query (rare but movie and show exists for Run in 2020)
					ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
					name_lower = name.lower()
					if any(re.search(item, name_lower) for item in ep_strings): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)

				try:
					seeders = int(file['seeders'])
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = file['size']
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				sources_append({
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
					'provider': 'rutor', 'hash': hash, 'url': url, 'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders
				})
			except:
				source_utils.scraper_error('RUTOR')
		return sources

	def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
		if not data: return []
		files = []
		sources = []
		sources_append = sources.append
		try:
			aliases = source_utils.aliases_to_array(data['aliases'])
			title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
			imdb = data['imdb']
			year = data['year']
			season_x = data['season']
			season_xx = season_x.zfill(2)

			query = re.sub(r'[^A-Za-z0-9\s\.-]+', '', title)
			if search_series: urls = [
				self.base_link + self.search_link % (self.tvshow_params, quote_plus(query + ' Season')),
				self.base_link + self.search_link % (self.tvshow_params, quote_plus(query + ' Complete'))]
			else: urls = [
				self.base_link + self.search_link % (self.tvshow_params, quote_plus(query + ' S%s' % season_xx)),
				self.base_link + self.search_link % (self.tvshow_params, quote_plus(query + ' Season %s' % season_x))]
			thread = source_utils.Thread(self.get_sources, urls[0], files)
			thread.start()
			self.get_sources(urls[1], files)
			thread.join()
			undesirables = source_utils.get_undesirables()
			check_foreign_audio = source_utils.check_foreign_audio()
		except:
			source_utils.scraper_error('RUTOR')
			return sources

		for file in files:
			try:
				hash = file['hash']
				name = file['title']

				name = source_utils.clean_name(name).replace('2./.', '').replace('./.', '').replace('|.', '').replace('...', '.').replace('..', '.').replace(',.', '.').replace(':.', '.')

				episode_start, episode_end = 0, 0
				if not search_series:
					if not bypass_filter:
						valid, episode_start, episode_end = source_utils.filter_season_pack(title, aliases, year, season_x, name)
						if not valid: continue
					package = 'season'

				elif search_series:
					if not bypass_filter:
						valid, last_season = source_utils.filter_show_pack(title, aliases, imdb, year, season_x, name, total_seasons)
						if not valid: continue
					else: last_season = total_seasons
					package = 'show'

				name_info = source_utils.info_from_name(name, title, year, season=season_x, pack=package)
				if source_utils.remove_lang(name_info, check_foreign_audio): continue
				if undesirables and source_utils.remove_undesirables(name_info, undesirables): continue

				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, name)
				try:
					seeders = int(file['seeders'])
					if self.min_seeders > seeders: continue
				except: seeders = 0

				quality, info = source_utils.get_release_quality(name_info, url)
				try:
					size = file['size']
					dsize, isize = source_utils._size(size)
					info.insert(0, isize)
				except: dsize = 0
				info = ' | '.join(info)

				item = {
					'source': 'torrent', 'language': 'en', 'direct': False, 'debridonly': True,
					'provider': 'rutor', 'hash': hash, 'url': url,  'name': name, 'name_info': name_info,
					'quality': quality, 'info': info, 'size': dsize, 'seeders': seeders, 'package': package
				}
				if search_series: item.update({'last_season': last_season})
				elif episode_start: item.update({'episode_start': episode_start, 'episode_end': episode_end}) # for partial season packs
				sources_append(item)
			except:
				source_utils.scraper_error('RUTOR')
		return sources

